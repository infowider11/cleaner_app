import 'dart:developer';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import 'package:cleanerapp/constants/colors.dart';
import 'package:cleanerapp/constants/images_url.dart';
import 'package:cleanerapp/modals/user_modal.dart';
import 'package:cleanerapp/pages/forgotpassword.dart';
import 'package:cleanerapp/pages/homescreen.dart';
import 'package:cleanerapp/services/local_services.dart';
import 'package:cleanerapp/services/webservices.dart';
import 'package:cleanerapp/widgets/custom_text_field.dart';
import 'package:cleanerapp/widgets/showSnackbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/global_data.dart';
import '../constants/sized_box.dart';
import '../constants/toast.dart';
import '../functions/navigation_functions.dart';
import '../services/api_urls.dart';
import '../widgets/CustomTexts.dart';
import '../widgets/round_edged_button.dart';
class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // final UserModal recipecardsdata;

  TextEditingController email  =TextEditingController();
  TextEditingController password  =TextEditingController();
  bool check=true;
  bool load=false;
  bool isshow=false;



  @override
  Widget build(BuildContext context) {
    TextEditingController email=TextEditingController();
    TextEditingController password=TextEditingController();
    return SafeArea(
      child: Scaffold(
          backgroundColor:MyColors.primaryColor,
          body:Padding(
            padding: const EdgeInsets.all(8.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  vSizedBox6,
                  Center(child: Image.asset(MyImages.splash,height: 162,width: 162,),),
                  ParagraphText('Login',color: Color(0xffffffff),fontWeight: FontWeight.w600,fontSize: 22,),
                  vSizedBox2,
                  CustomTextField(
                    controller: email,
                    hintText: 'Email Address',
                    hintcolor: Colors.white,
                    textColor: Colors.white,
                    bgColor:Colors.transparent,
                    borderRadius: 8,
                    keyboardType: TextInputType.emailAddress,
                    onChanged: (val){
                      email.selection = TextSelection.fromPosition(
                        TextPosition(offset: email.text.length),
                      );
                    },
                  ),
                  vSizedBox2,
                  CustomTextField(
                    controller: password,
                    hintcolor: Colors.white,
                    textColor: Colors.white,
                    hintText: 'Password',
                    bgColor:Colors.transparent,
                    borderRadius: 8,
                    obscureText:!isshow,
                    suffix2: GestureDetector(
                        onTap: (){
                          isshow = !isshow;
                          setState(() {});
                        },
                        child: Icon(isshow==false? CupertinoIcons.eye_fill : CupertinoIcons.eye_slash_fill, color: MyColors.whiteColor,)),
                  ),
                  vSizedBox2,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: (){
                          push(context: context, screen: ForgotPassword());
                        },
                          child: ParagraphText('Forgot Password?',color: Color(0xffffffff),fontSize: 12,))
                    ],
                  ),
                  vSizedBox2,
                  RoundEdgedButton(text: 'Login',fontSize: 18,borderRadius: 8,isLoad: load,color: Color(0xffffffff),textColor: MyColors.primaryColor,
                    onTap: () async{


                        // users.forEach((element) {
                        //   userData = element;
                          // print(userData!.emailId);
                          // if (email.text == 'Admin@gmail.com') {
                          //   xyz = UserType.Admin;
                          //   pushReplacement(context: context, screen: HomeScreen(userType: UserType.Admin, title: 'Welcome ! Admin',));
                          // } else if (email.text == 'Maintenance@gmail.com') {
                          //   xyz = UserType.Maintenance;
                          //   pushReplacement(
                          //       context: context,
                          //       screen: HomeScreen(
                          //         userType: UserType.Maintenance,
                          //         title: 'Welcome ! Maintenance',
                          //       ));
                          // } else if (email.text == 'Logistics@gmail.com') {
                          //   xyz = UserType.Logistics;
                          //   pushReplacement(
                          //       context: context,
                          //       screen: HomeScreen(
                          //         userType: UserType.Logistics,
                          //         title: 'Welcome ! Logistics',
                          //       ));
                          // } else if (email.text == 'Supervisor@gmail.com') {
                          //   xyz = UserType.Supervisor;
                          //   pushReplacement(
                          //       context: context,
                          //       screen: HomeScreen(
                          //         userType: UserType.Supervisor,
                          //         title: 'Welcome ! Supervisor',
                          //       ));
                          // } else if (email.text == 'Cleaners@gmail.com') {
                          //   xyz = UserType.Cleaners;
                          //   pushReplacement(
                          //       context: context,
                          //       screen: HomeScreen(
                          //         userType: UserType.Cleaners,
                          //         title: 'Welcome ! Cleaners',
                          //       ));
                          // }else



                          if (email.text.length == 0){
                            toast('Please enter email');
                          } else  if(email.text.length > 0 && !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email.text)){
                            toast('Please enter valid email');
                          }else if (password.text.length == 0){
                            toast('Please enter password');
                          } else if (password.text.length > 0 && password.text.length < 6){
                            toast('Password should not be less than 6 characters');
                            ///strong password validation
                          // }else  if(password.text.length > 0 && !RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$').hasMatch(password.text)){
                          //   toast('Please enter strong password (It should contain block letter, special character & number)');
                          }
                          else {
                            ///api integration
                            Map<String,dynamic> login_request={
                              'email':email.text,
                              'password':password.text,
                            };

                            setState(() {
                              load=true;
                            });
                            // final Response= await Webservices.postData(apiUrl: ApiUrls.login , request: login_request);
                            final Response = await http.post(Uri.parse(ApiUrls.login), body: login_request);
                            var jsonResponse = convert.jsonDecode(Response.body);
                            log("Login response---$jsonResponse");
                            log("status---${jsonResponse['status']}");

                            setState(() {
                              load=false;
                            });
                            if(jsonResponse['status'].toString() =="1"){
                             print( "user type${jsonResponse['data']['type']}");

                             if(jsonResponse['data']['type'] != null || jsonResponse['data']['type'] != ""){
                               prefs.setString("userType", jsonResponse['data']['type']);
                               prefs.setString("userName", jsonResponse['data']['name']);
                               prefs.setString("userId", jsonResponse['data']['id']);
                               if(jsonResponse['data']['type'].toString() == "1"){
                                 Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => HomeScreen(userType: UserType.Secratary, title: "Welcome ! ${jsonResponse['data']['name']}",)), (Route<dynamic> route) => false);
                                 toast("${jsonResponse['message']}");
                               }else if(jsonResponse['data']['type'].toString() == "2"){
                                 Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => HomeScreen(userType: UserType.Supervisor, title: "Welcome ! ${jsonResponse['data']['name']}",)), (Route<dynamic> route) => false);
                                 toast("${jsonResponse['message']}");
                               }else if(jsonResponse['data']['type'].toString() == "3"){
                                 Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => HomeScreen(userType: UserType.Logistics, title: "Welcome ! ${jsonResponse['data']['name']}",)), (Route<dynamic> route) => false);
                                 toast("${jsonResponse['message']}");
                               }else if(jsonResponse['data']['type'].toString() == "4"){
                                 Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => HomeScreen(userType: UserType.Maintenance, title: "Welcome ! ${jsonResponse['data']['name']}",)), (Route<dynamic> route) => false);
                                 toast("${jsonResponse['message']}");
                               }else if(jsonResponse['data']['type'].toString() == "5"){
                                 Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => HomeScreen(userType: UserType.Cleaners, title: "Welcome ! ${jsonResponse['data']['name']}",)), (Route<dynamic> route) => false);
                                 toast("${jsonResponse['message']}");
                               } else{
                                 toast("${jsonResponse['message']}");
                               }
                             }else{
                               toast("${jsonResponse['message']}");
                             }
                            }else{
                              toast("${jsonResponse['message']}");
                            }
                          }
                        // });

                    },
                  )

                ],

              ),
            ),
          )

      ),
    );
  }
}
